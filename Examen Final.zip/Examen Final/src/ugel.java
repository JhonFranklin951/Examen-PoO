import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class ugel extends JFrame{
    private JTable tablainstituciones;
    private JTextField textCodigo;
    private JTextField textNombre;
    private JTextField textDireccion;
    private JTextField textDistrito;
    private JTextField textNivel;
    private JTextField textGestion;
    private JButton listarButton;
    private JButton guardarButton;
    private JButton modificarButton;
    private JButton eliminarButton;
    private JPanel PanelUgel;

    String url="jdbc:mysql://localhost:3306/ugel_sr";
    String usuario_bd="root";
    String pasword_bd="";

    public ugel(){
        setContentPane(PanelUgel);
        setTitle("Ugel");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setSize(700,500);
        setResizable(false);
        setVisible(true);

        listarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Connection PruebaConexion = null;
                PruebaConexion = conexion();

                if(PruebaConexion != null){
                    System.out.println("Correcto, la BD ha respondido");

                    Statement statement = null;
                    ResultSet resulset = null;

                    String sql = "select * from institucion  ";

                    try {
                        statement = PruebaConexion.createStatement();
                        resulset = statement.executeQuery(sql);

                        DefaultTableModel modelo = new DefaultTableModel();
                        modelo.setColumnIdentifiers(new Object[]{"id","codigo_modular", "nombre", "direccion","distrito","nivel","gestion"});
                        modelo.setRowCount(0);

                        while(resulset.next()){
                            Object[] fila = new Object[7];
                            fila[0] = resulset.getInt("id");
                            fila[1] = resulset.getString("codigo_modular");
                            fila[2] = resulset.getString("nombre");
                            fila[3] = resulset.getString("direccion");
                            fila[4] = resulset.getString("distrito");
                            fila[5] = resulset.getString("nivel");
                            fila[6] = resulset.getString("gestion");
                            modelo.addRow(fila);
                        }
                        tablainstituciones.setModel(modelo);

                    }catch (SQLException ex){
                        System.out.println("Error al obtener la conexion");
                    }


                }else {
                    System.out.println("La BD No ha respondido");
                }
            }
        });

        guardarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Connection LaConexion = null;
                LaConexion = conexion();

                if (LaConexion != null) {
                    System.out.println("Correcto, la BD ha respondido");
                    int codigo_modular = Integer.parseInt(textCodigo.getText());
                    String nombre = textNombre.getText();
                    String direccion = textDireccion.getText();
                    String distrito = textDistrito.getText();
                    String nivel = textNivel.getText();
                    String gestion = textGestion.getText();

                    try {
                        String sql ="INSERT INTO institucion(codigo_modular,nombre,direccion,distrito,nivel,gestion) VALUES (?,?,?,?,?,?)";
                        PreparedStatement statement = LaConexion.prepareStatement(sql);
                        statement.setInt(1, codigo_modular);
                        statement.setString(2, nombre);
                        statement.setString(3, direccion);
                        statement.setString(4,distrito);
                        statement.setString(5, nivel);
                        statement.setString(6, gestion);
                        statement.execute();
                        JOptionPane.showMessageDialog(null, "Institucion guardada correctamente");


                    }catch (SQLException ex){
                        System.out.println(ex.getMessage());
                        System.out.println("Error al guardar el libro");
                    }


                }else {
                    System.out.println("La BD No ha respondido");

                }

            }
        });
        modificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int FilaSeleccionada = tablainstituciones.getSelectedRow();
                System.out.println("Fila Seleccionada: " + FilaSeleccionada);
                if (FilaSeleccionada ==-1) {
                    JOptionPane.showMessageDialog(null, "Seleccione una Fila");
                }
                int id = Integer.parseInt(tablainstituciones.getModel().getValueAt(FilaSeleccionada,0).toString());
                int codigo_modular = Integer.parseInt(tablainstituciones.getModel().getValueAt(FilaSeleccionada,1).toString());
                String nombre = tablainstituciones.getModel().getValueAt(FilaSeleccionada,2).toString();
                String direccion = tablainstituciones.getModel().getValueAt(FilaSeleccionada,3).toString();
                String distrito = tablainstituciones.getModel().getValueAt(FilaSeleccionada,4).toString();
                String nivel = tablainstituciones.getModel().getValueAt(FilaSeleccionada,5).toString();
                String gestion = tablainstituciones.getModel().getValueAt(FilaSeleccionada,6).toString();
                System.out.println(codigo_modular+" "+nombre+" "+direccion+" "+distrito+" "+nivel+" "+gestion);


                Connection conexion_para_modificar=null;
                conexion_para_modificar = conexion();


                DialogModificar Ventana = new DialogModificar(id,codigo_modular,nombre,direccion,distrito,nivel,gestion,conexion_para_modificar);
                Ventana.setVisible(true);

            }
        });
        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Connection LaConexion = null;
                LaConexion = conexion();

                if (LaConexion != null) {

                    int confirmacion = JOptionPane.showOptionDialog(null,
                            "Esta seguro de eliminar este producto?",
                            "Cuidado!!!",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.QUESTION_MESSAGE,
                            null,
                            new  Object[]{"Si,Eliminar","NO"},
                            "NO"
                    );
                    if (confirmacion!=JOptionPane.YES_OPTION){
                        return;
                    }

                    int FilaSeleccionada = tablainstituciones.getSelectedRow();
                    System.out.println("Fila Seleccionada: " + FilaSeleccionada);


                    int id = Integer.parseInt(tablainstituciones.getModel().getValueAt(FilaSeleccionada,0).toString());
                    try{
                        String sql ="DELETE FROM institucion WHERE id=?";
                        PreparedStatement statement = LaConexion.prepareStatement(sql);
                        statement.setInt(1,id);
                        statement.execute();
                        JOptionPane.showMessageDialog(null, "Institucion eliminada correctamente");

                    }catch (Exception ex){
                        System.out.println(ex.getMessage());
                    }

                }
            }
        });
    }




    public static void main(String[] args) {
        new ugel();
    }

    public Connection conexion(){
        Connection conexion=null;
        try {
            conexion= DriverManager.getConnection(url,usuario_bd,pasword_bd);
        }catch (SQLException e){
            System.out.println("No se puede conectar con la base de datos");
        }
        return conexion;
    }
}
