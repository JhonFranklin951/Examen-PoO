import javax.swing.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DialogModificar extends JDialog {
    private JPanel contentPane;
    private JButton buttonOK;
    private JButton buttonCancel;
    private JTextField textI;
    private JTextField textCM;
    private JTextField textN;
    private JTextField textD;
    private JTextField textDIS;
    private JTextField textNIV;
    private JTextField textG;

    public DialogModificar(int id,int codigo_modular,String nombre,String direccion,String distrito,String nivel,String gestion, Connection conex) {
        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(buttonOK);
        setLocationRelativeTo(null);
        setSize(300,600);

        textI.setText(id+"");
        textCM.setText(codigo_modular+"");
        textN.setText(nombre);
        textD.setText(direccion);
        textDIS.setText(distrito);
        textNIV.setText(nivel);
        textG.setText(gestion);



        buttonOK.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String sql="UPDATE institucion SET codigo_modular=?, nombre=?, direccion=? ,distrito=? ,nivel=? ,gestion=? WHERE id=? ";
                    PreparedStatement ps = conex.prepareStatement(sql);
                    ps.setInt(1, Integer.parseInt(textCM.getText()));
                    ps.setString(2,textN.getText());
                    ps.setString(3, textD.getText());
                    ps.setString(4, textDIS.getText());
                    ps.setString(5,textNIV.getText());
                    ps.setString(6,textG.getText());
                    ps.setInt(7,id);

                    ps.execute();
                    JOptionPane.showMessageDialog(null, "Datos actualizados exitosamente");
                    dispose();

                }catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                    System.out.println("Error: "+ex);
                }
            }
        });

        buttonCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        });

        // call onCancel() when cross is clicked
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

        // call onCancel() on ESCAPE
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }


    private void onCancel() {
        // add your code here if necessary
        dispose();
    }

}
